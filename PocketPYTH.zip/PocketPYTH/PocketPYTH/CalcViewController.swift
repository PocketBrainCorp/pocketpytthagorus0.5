//
//  CalcViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 19.10.2021.
//

import UIKit

class CalcViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func goBackMain(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
